export const environment = {
  production: true,
  apiKey: "AIzaSyDBKR4Ra6RwlxznrtLxzwaIFlKTXZntYZ0",
  authDomain: "kapcq-dev.firebaseapp.com",
  databaseURL: "https://kapcq-dev.firebaseio.com",
  projectId: "kapcq-dev",
  storageBucket: "kapcq-dev.appspot.com",
  messagingSenderId: "628962386546"
};
